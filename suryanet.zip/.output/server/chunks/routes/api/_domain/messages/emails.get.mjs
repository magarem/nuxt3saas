import { d as defineEventHandler, b as getCookie, a as getDatabase } from '../../../../nitro/nitro.mjs';
import jwt from 'jsonwebtoken';
import 'better-sqlite3';
import 'path';
import 'node:fs/promises';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'lru-cache';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@primevue/core/base/style';
import '@primevue/core/basecomponent/style';
import '@primeuix/styles/autocomplete';
import '@primeuix/utils/object';
import '@primeuix/styles/cascadeselect';
import '@primeuix/styles/checkbox';
import '@primeuix/styles/checkboxgroup';
import '@primeuix/styles/colorpicker';
import '@primeuix/styles/datepicker';
import '@primeuix/styles/floatlabel';
import '@primeuix/styles/iconfield';
import '@primeuix/styles/iftalabel';
import '@primeuix/styles/inputchips';
import '@primeuix/styles/inputgroup';
import '@primeuix/styles/inputnumber';
import '@primeuix/styles/inputotp';
import '@primeuix/styles/inputtext';
import '@primeuix/styles/knob';
import '@primeuix/styles/listbox';
import '@primeuix/styles/multiselect';
import '@primeuix/styles/password';
import '@primeuix/styles/radiobutton';
import '@primeuix/styles/radiobuttongroup';
import '@primeuix/styles/rating';
import '@primeuix/styles/select';
import '@primeuix/styles/selectbutton';
import '@primeuix/styles/slider';
import '@primeuix/styles/textarea';
import '@primeuix/styles/togglebutton';
import '@primeuix/styles/toggleswitch';
import '@primeuix/styles/treeselect';
import '@primeuix/styles/button';
import '@primeuix/styles/buttongroup';
import '@primeuix/styles/speeddial';
import '@primeuix/styles/splitbutton';
import '@primeuix/styles/datatable';
import '@primeuix/styles/dataview';
import '@primeuix/styles/orderlist';
import '@primeuix/styles/organizationchart';
import '@primeuix/styles/paginator';
import '@primeuix/styles/picklist';
import '@primeuix/styles/tree';
import '@primeuix/styles/treetable';
import '@primeuix/styles/timeline';
import '@primeuix/styles/virtualscroller';
import '@primeuix/styles/accordion';
import '@primeuix/styles/card';
import '@primeuix/styles/divider';
import '@primeuix/styles/fieldset';
import '@primeuix/styles/panel';
import '@primeuix/styles/scrollpanel';
import '@primeuix/styles/splitter';
import '@primeuix/styles/stepper';
import '@primeuix/styles/tabview';
import '@primeuix/styles/tabs';
import '@primeuix/styles/toolbar';
import '@primeuix/styles/confirmdialog';
import '@primeuix/styles/confirmpopup';
import '@primeuix/styles/dialog';
import '@primeuix/styles/drawer';
import '@primeuix/styles/popover';
import '@primeuix/styles/fileupload';
import '@primeuix/styles/breadcrumb';
import '@primeuix/styles/contextmenu';
import '@primeuix/styles/dock';
import '@primeuix/styles/menu';
import '@primeuix/styles/menubar';
import '@primeuix/styles/megamenu';
import '@primeuix/styles/panelmenu';
import '@primeuix/styles/steps';
import '@primeuix/styles/tabmenu';
import '@primeuix/styles/tieredmenu';
import '@primeuix/styles/message';
import '@primeuix/styles/inlinemessage';
import '@primeuix/styles/toast';
import '@primeuix/styles/carousel';
import '@primeuix/styles/galleria';
import '@primeuix/styles/image';
import '@primeuix/styles/imagecompare';
import '@primeuix/styles/avatar';
import '@primeuix/styles/badge';
import '@primeuix/styles/blockui';
import '@primeuix/styles/chip';
import '@primeuix/styles/inplace';
import '@primeuix/styles/metergroup';
import '@primeuix/styles/overlaybadge';
import '@primeuix/styles/scrolltop';
import '@primeuix/styles/skeleton';
import '@primeuix/styles/progressbar';
import '@primeuix/styles/progressspinner';
import '@primeuix/styles/tag';
import '@primeuix/styles/terminal';
import '@primevue/forms/form/style';
import '@primevue/forms/formfield/style';
import '@primeuix/styles/tooltip';
import '@primeuix/styles/ripple';
import '@primeuix/styled';
import 'node:url';
import 'xss';

const emails_get = defineEventHandler(async (event) => {
  const mailboxName = event.context.params.mailboxName;
  try {
    const domain = event.context.params.domain;
    console.log("domain/////222//////:", domain);
    console.log("mailboxName/////222//////:", mailboxName);
    const authToken = getCookie(event, "auth_token");
    const decoded = jwt.verify(authToken, "chave_secreta");
    console.log("decoded:", decoded);
    const db = getDatabase(domain);
    const mailboxResult = db.prepare(`SELECT id FROM Mailboxes WHERE name = '${mailboxName}'`).get();
    console.log("mailboxResult:", mailboxResult);
    if (mailboxResult && mailboxResult.id) {
      const mailboxId = mailboxResult.id;
      console.log("mailboxId:", mailboxId);
      let emailsData = [];
      if (mailboxName === "Sent") {
        emailsData = db.prepare(`
          SELECT
            m.id,
            m.sender,
            m.receiver,
            m.subject,
            m.body,
            m.sent_at AS date,
            m.is_read
          FROM messages m
          WHERE m.sender = ${decoded.id}
          ORDER BY m.sent_at DESC
          `).all();
        console.log("emailsData:", emailsData);
        db.close();
        return emailsData.map((email) => ({
          id: `e${email.id}`,
          // Create a client-side ID
          from: email.sender,
          subject: email.subject,
          body: email.body,
          date: new Date(email.date),
          isRead: !!email.is_read
          // Convert 0/1 to boolean
        }));
      }
      if (mailboxName === "Inbox") {
        console.log("inbox~~decoded.id:", decoded.id);
        emailsData = db.prepare(`
          SELECT
            m.id,
            m.sender,
            m.receiver,
            m.subject,
            m.body,
            m.sent_at AS date,
            m.is_read
          FROM messages m
          WHERE m.receiver = ${decoded.id}
          ORDER BY m.sent_at DESC
          `).all();
        console.log("emailsData:", emailsData);
        db.close();
        return emailsData.map((email) => ({
          id: `e${email.id}`,
          // Create a client-side ID
          from: email.sender,
          subject: email.subject,
          body: email.body,
          date: new Date(email.date),
          isRead: !!email.is_read
          // Convert 0/1 to boolean
        }));
      }
    } else {
      db.close();
      return { error: `Mailbox "${mailboxName}" not found.` };
    }
  } catch (error) {
    console.error("Error fetching emails:", error);
    return { error: "Failed to fetch emails." };
  }
});

export { emails_get as default };
//# sourceMappingURL=emails.get.mjs.map
