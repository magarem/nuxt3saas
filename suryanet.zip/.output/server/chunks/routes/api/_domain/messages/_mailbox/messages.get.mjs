import { d as defineEventHandler, j as getQuery, f as createError, a as getDatabase } from '../../../../../nitro/nitro.mjs';
import 'better-sqlite3';
import 'path';
import 'node:fs/promises';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'lru-cache';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@primevue/core/base/style';
import '@primevue/core/basecomponent/style';
import '@primeuix/styles/autocomplete';
import '@primeuix/utils/object';
import '@primeuix/styles/cascadeselect';
import '@primeuix/styles/checkbox';
import '@primeuix/styles/checkboxgroup';
import '@primeuix/styles/colorpicker';
import '@primeuix/styles/datepicker';
import '@primeuix/styles/floatlabel';
import '@primeuix/styles/iconfield';
import '@primeuix/styles/iftalabel';
import '@primeuix/styles/inputchips';
import '@primeuix/styles/inputgroup';
import '@primeuix/styles/inputnumber';
import '@primeuix/styles/inputotp';
import '@primeuix/styles/inputtext';
import '@primeuix/styles/knob';
import '@primeuix/styles/listbox';
import '@primeuix/styles/multiselect';
import '@primeuix/styles/password';
import '@primeuix/styles/radiobutton';
import '@primeuix/styles/radiobuttongroup';
import '@primeuix/styles/rating';
import '@primeuix/styles/select';
import '@primeuix/styles/selectbutton';
import '@primeuix/styles/slider';
import '@primeuix/styles/textarea';
import '@primeuix/styles/togglebutton';
import '@primeuix/styles/toggleswitch';
import '@primeuix/styles/treeselect';
import '@primeuix/styles/button';
import '@primeuix/styles/buttongroup';
import '@primeuix/styles/speeddial';
import '@primeuix/styles/splitbutton';
import '@primeuix/styles/datatable';
import '@primeuix/styles/dataview';
import '@primeuix/styles/orderlist';
import '@primeuix/styles/organizationchart';
import '@primeuix/styles/paginator';
import '@primeuix/styles/picklist';
import '@primeuix/styles/tree';
import '@primeuix/styles/treetable';
import '@primeuix/styles/timeline';
import '@primeuix/styles/virtualscroller';
import '@primeuix/styles/accordion';
import '@primeuix/styles/card';
import '@primeuix/styles/divider';
import '@primeuix/styles/fieldset';
import '@primeuix/styles/panel';
import '@primeuix/styles/scrollpanel';
import '@primeuix/styles/splitter';
import '@primeuix/styles/stepper';
import '@primeuix/styles/tabview';
import '@primeuix/styles/tabs';
import '@primeuix/styles/toolbar';
import '@primeuix/styles/confirmdialog';
import '@primeuix/styles/confirmpopup';
import '@primeuix/styles/dialog';
import '@primeuix/styles/drawer';
import '@primeuix/styles/popover';
import '@primeuix/styles/fileupload';
import '@primeuix/styles/breadcrumb';
import '@primeuix/styles/contextmenu';
import '@primeuix/styles/dock';
import '@primeuix/styles/menu';
import '@primeuix/styles/menubar';
import '@primeuix/styles/megamenu';
import '@primeuix/styles/panelmenu';
import '@primeuix/styles/steps';
import '@primeuix/styles/tabmenu';
import '@primeuix/styles/tieredmenu';
import '@primeuix/styles/message';
import '@primeuix/styles/inlinemessage';
import '@primeuix/styles/toast';
import '@primeuix/styles/carousel';
import '@primeuix/styles/galleria';
import '@primeuix/styles/image';
import '@primeuix/styles/imagecompare';
import '@primeuix/styles/avatar';
import '@primeuix/styles/badge';
import '@primeuix/styles/blockui';
import '@primeuix/styles/chip';
import '@primeuix/styles/inplace';
import '@primeuix/styles/metergroup';
import '@primeuix/styles/overlaybadge';
import '@primeuix/styles/scrolltop';
import '@primeuix/styles/skeleton';
import '@primeuix/styles/progressbar';
import '@primeuix/styles/progressspinner';
import '@primeuix/styles/tag';
import '@primeuix/styles/terminal';
import '@primevue/forms/form/style';
import '@primevue/forms/formfield/style';
import '@primeuix/styles/tooltip';
import '@primeuix/styles/ripple';
import '@primeuix/styled';
import 'node:url';
import 'xss';

const messages_get = defineEventHandler(async (event) => {
  const domain = event.context.params.domain;
  const mailbox = event.context.params.mailbox;
  const query = getQuery(event);
  const userId = parseInt(query.userId);
  const excludeDeleted = query.excludeDeleted === "true";
  if (isNaN(userId) || !["inbox", "sent", "deleted"].includes(mailbox)) {
    return createError({
      statusCode: 400,
      statusMessage: "Invalid userId or mailbox."
    });
  }
  const db = getDatabase(domain);
  if (!db) {
    return createError({
      statusCode: 500,
      statusMessage: "Failed to connect to the database."
    });
  }
  try {
    let sql = `
      SELECT
        m.id,
        m.sender_id,
        sender.nome AS sender_name,
        m.receiver_id,
        receiver.nome AS receiver_name,
        m.subject,
        m.body,
        strftime('%Y-%m-%dT%H:%M:%fZ', m.sent_at) AS date,
        um.is_read,
        um.is_deleted,
        strftime('%Y-%m-%dT%H:%M:%fZ', um.deleted_at) AS deleted_at,
        um.mailbox AS user_mailbox
      FROM user_messages um
      JOIN messages m ON um.message_id = m.id
      LEFT JOIN users sender ON m.sender_id = sender.id
      LEFT JOIN users receiver ON m.receiver_id = receiver.id
      WHERE um.user_id = ? AND um.mailbox = ?
      
    `;
    const params = [userId, mailbox];
    if (excludeDeleted && mailbox !== "deleted") {
      sql += " AND um.is_deleted = 0";
    }
    sql += " ORDER BY m.sent_at DESC";
    console.log("sql:", sql);
    const stmt = db.prepare(sql);
    const messagesData = stmt.all(params);
    db.close();
    return messagesData.map((message) => ({
      id: message.id,
      senderId: message.sender_id,
      senderName: message.sender_name,
      receiverId: message.receiver_id,
      receiverName: message.receiver_name,
      subject: message.subject,
      body: message.body,
      date: new Date(message.date),
      isRead: !!message.is_read,
      isDeleted: !!message.is_deleted,
      deletedAt: message.deleted_at ? new Date(message.deleted_at) : null,
      mailbox: message.user_mailbox
    }));
  } catch (error) {
    console.error("Error fetching messages:", error);
    db.close();
    return createError({
      statusCode: 500,
      statusMessage: "Error fetching messages.",
      stack: error.stack
    });
  }
});

export { messages_get as default };
//# sourceMappingURL=messages.get.mjs.map
