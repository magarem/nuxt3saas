import jwt from 'jsonwebtoken';
import { d as defineEventHandler, g as getRouterParams, a as getDatabase, b as getCookie, s as sendRedirect, c as sendError, e as createError } from '../../../../nitro/nitro.mjs';
import 'better-sqlite3';
import 'path';
import 'node:fs/promises';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'lru-cache';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@primevue/core/base/style';
import '@primevue/core/basecomponent/style';
import '@primeuix/styles/autocomplete';
import '@primeuix/utils/object';
import '@primeuix/styles/cascadeselect';
import '@primeuix/styles/checkbox';
import '@primeuix/styles/checkboxgroup';
import '@primeuix/styles/colorpicker';
import '@primeuix/styles/datepicker';
import '@primeuix/styles/floatlabel';
import '@primeuix/styles/iconfield';
import '@primeuix/styles/iftalabel';
import '@primeuix/styles/inputchips';
import '@primeuix/styles/inputgroup';
import '@primeuix/styles/inputnumber';
import '@primeuix/styles/inputotp';
import '@primeuix/styles/inputtext';
import '@primeuix/styles/knob';
import '@primeuix/styles/listbox';
import '@primeuix/styles/multiselect';
import '@primeuix/styles/password';
import '@primeuix/styles/radiobutton';
import '@primeuix/styles/radiobuttongroup';
import '@primeuix/styles/rating';
import '@primeuix/styles/select';
import '@primeuix/styles/selectbutton';
import '@primeuix/styles/slider';
import '@primeuix/styles/textarea';
import '@primeuix/styles/togglebutton';
import '@primeuix/styles/toggleswitch';
import '@primeuix/styles/treeselect';
import '@primeuix/styles/button';
import '@primeuix/styles/buttongroup';
import '@primeuix/styles/speeddial';
import '@primeuix/styles/splitbutton';
import '@primeuix/styles/datatable';
import '@primeuix/styles/dataview';
import '@primeuix/styles/orderlist';
import '@primeuix/styles/organizationchart';
import '@primeuix/styles/paginator';
import '@primeuix/styles/picklist';
import '@primeuix/styles/tree';
import '@primeuix/styles/treetable';
import '@primeuix/styles/timeline';
import '@primeuix/styles/virtualscroller';
import '@primeuix/styles/accordion';
import '@primeuix/styles/card';
import '@primeuix/styles/divider';
import '@primeuix/styles/fieldset';
import '@primeuix/styles/panel';
import '@primeuix/styles/scrollpanel';
import '@primeuix/styles/splitter';
import '@primeuix/styles/stepper';
import '@primeuix/styles/tabview';
import '@primeuix/styles/tabs';
import '@primeuix/styles/toolbar';
import '@primeuix/styles/confirmdialog';
import '@primeuix/styles/confirmpopup';
import '@primeuix/styles/dialog';
import '@primeuix/styles/drawer';
import '@primeuix/styles/popover';
import '@primeuix/styles/fileupload';
import '@primeuix/styles/breadcrumb';
import '@primeuix/styles/contextmenu';
import '@primeuix/styles/dock';
import '@primeuix/styles/menu';
import '@primeuix/styles/menubar';
import '@primeuix/styles/megamenu';
import '@primeuix/styles/panelmenu';
import '@primeuix/styles/steps';
import '@primeuix/styles/tabmenu';
import '@primeuix/styles/tieredmenu';
import '@primeuix/styles/message';
import '@primeuix/styles/inlinemessage';
import '@primeuix/styles/toast';
import '@primeuix/styles/carousel';
import '@primeuix/styles/galleria';
import '@primeuix/styles/image';
import '@primeuix/styles/imagecompare';
import '@primeuix/styles/avatar';
import '@primeuix/styles/badge';
import '@primeuix/styles/blockui';
import '@primeuix/styles/chip';
import '@primeuix/styles/inplace';
import '@primeuix/styles/metergroup';
import '@primeuix/styles/overlaybadge';
import '@primeuix/styles/scrolltop';
import '@primeuix/styles/skeleton';
import '@primeuix/styles/progressbar';
import '@primeuix/styles/progressspinner';
import '@primeuix/styles/tag';
import '@primeuix/styles/terminal';
import '@primevue/forms/form/style';
import '@primevue/forms/formfield/style';
import '@primeuix/styles/tooltip';
import '@primeuix/styles/ripple';
import '@primeuix/styled';
import 'node:url';
import 'xss';

const _page_ = defineEventHandler(async (event) => {
  var _a;
  const { domain, user, page } = getRouterParams(event);
  const db = getDatabase(domain);
  const authToken = getCookie(event, "auth_token");
  if (!authToken) {
    return sendRedirect(event, `/${domain}/${user}/forbidden`);
  }
  if (!db) {
    return sendError(event, createError({ statusCode: 500, statusMessage: `Database not found for domain: ${domain}` }));
  }
  try {
    const decoded = jwt.verify(authToken, process.env.JWT_SECRET || "chave_secreta");
    if (decoded.domain !== domain) {
      return { success: false, statusCode: 222, statusMessage: `Acesso negado` };
    }
    const pageRoles = db.prepare("SELECT role_id FROM page_roles WHERE page_id = (SELECT id FROM pages WHERE page = ?)").all(page);
    console.log("Page roles:", pageRoles);
    if (!pageRoles || pageRoles.length === 0) {
      return sendError(event, createError({ statusCode: 404, statusMessage: `P\xE1gina n\xE3o encontrada ou sem roles configuradas` }));
    }
    const pageRolesArray = pageRoles.map((pr) => String(pr.role_id));
    console.log("Page roles array:", pageRolesArray);
    const userRoles = (_a = decoded.roles) == null ? void 0 : _a.replace(/\s+/g, "").split(",");
    console.log("User roles:", userRoles);
    if (!(userRoles == null ? void 0 : userRoles.some((role) => pageRolesArray.includes(role)))) {
      return { success: false, statusCode: 404, statusMessage: `Acesso negado` };
    }
    return { message: "Acesso concedido" };
  } catch (jwtError) {
    console.error("JWT verification error:", jwtError);
    return sendRedirect(event, `/${domain}/forbidden`);
  } finally {
    if (db && db.open) db.close();
  }
});

export { _page_ as default };
//# sourceMappingURL=_page_.mjs.map
