import { d as defineEventHandler, g as getRouterParams, l as readMultipartFormData, m as getRequestURL, b as getCookie, f as setResponseStatus } from '../../nitro/nitro.mjs';
import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import jwt from 'jsonwebtoken';
import 'better-sqlite3';
import 'node:fs/promises';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'lru-cache';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@primevue/core/base/style';
import '@primevue/core/basecomponent/style';
import '@primeuix/styles/autocomplete';
import '@primeuix/utils/object';
import '@primeuix/styles/cascadeselect';
import '@primeuix/styles/checkbox';
import '@primeuix/styles/checkboxgroup';
import '@primeuix/styles/colorpicker';
import '@primeuix/styles/datepicker';
import '@primeuix/styles/floatlabel';
import '@primeuix/styles/iconfield';
import '@primeuix/styles/iftalabel';
import '@primeuix/styles/inputchips';
import '@primeuix/styles/inputgroup';
import '@primeuix/styles/inputnumber';
import '@primeuix/styles/inputotp';
import '@primeuix/styles/inputtext';
import '@primeuix/styles/knob';
import '@primeuix/styles/listbox';
import '@primeuix/styles/multiselect';
import '@primeuix/styles/password';
import '@primeuix/styles/radiobutton';
import '@primeuix/styles/radiobuttongroup';
import '@primeuix/styles/rating';
import '@primeuix/styles/select';
import '@primeuix/styles/selectbutton';
import '@primeuix/styles/slider';
import '@primeuix/styles/textarea';
import '@primeuix/styles/togglebutton';
import '@primeuix/styles/toggleswitch';
import '@primeuix/styles/treeselect';
import '@primeuix/styles/button';
import '@primeuix/styles/buttongroup';
import '@primeuix/styles/speeddial';
import '@primeuix/styles/splitbutton';
import '@primeuix/styles/datatable';
import '@primeuix/styles/dataview';
import '@primeuix/styles/orderlist';
import '@primeuix/styles/organizationchart';
import '@primeuix/styles/paginator';
import '@primeuix/styles/picklist';
import '@primeuix/styles/tree';
import '@primeuix/styles/treetable';
import '@primeuix/styles/timeline';
import '@primeuix/styles/virtualscroller';
import '@primeuix/styles/accordion';
import '@primeuix/styles/card';
import '@primeuix/styles/divider';
import '@primeuix/styles/fieldset';
import '@primeuix/styles/panel';
import '@primeuix/styles/scrollpanel';
import '@primeuix/styles/splitter';
import '@primeuix/styles/stepper';
import '@primeuix/styles/tabview';
import '@primeuix/styles/tabs';
import '@primeuix/styles/toolbar';
import '@primeuix/styles/confirmdialog';
import '@primeuix/styles/confirmpopup';
import '@primeuix/styles/dialog';
import '@primeuix/styles/drawer';
import '@primeuix/styles/popover';
import '@primeuix/styles/fileupload';
import '@primeuix/styles/breadcrumb';
import '@primeuix/styles/contextmenu';
import '@primeuix/styles/dock';
import '@primeuix/styles/menu';
import '@primeuix/styles/menubar';
import '@primeuix/styles/megamenu';
import '@primeuix/styles/panelmenu';
import '@primeuix/styles/steps';
import '@primeuix/styles/tabmenu';
import '@primeuix/styles/tieredmenu';
import '@primeuix/styles/message';
import '@primeuix/styles/inlinemessage';
import '@primeuix/styles/toast';
import '@primeuix/styles/carousel';
import '@primeuix/styles/galleria';
import '@primeuix/styles/image';
import '@primeuix/styles/imagecompare';
import '@primeuix/styles/avatar';
import '@primeuix/styles/badge';
import '@primeuix/styles/blockui';
import '@primeuix/styles/chip';
import '@primeuix/styles/inplace';
import '@primeuix/styles/metergroup';
import '@primeuix/styles/overlaybadge';
import '@primeuix/styles/scrolltop';
import '@primeuix/styles/skeleton';
import '@primeuix/styles/progressbar';
import '@primeuix/styles/progressspinner';
import '@primeuix/styles/tag';
import '@primeuix/styles/terminal';
import '@primevue/forms/form/style';
import '@primevue/forms/formfield/style';
import '@primeuix/styles/tooltip';
import '@primeuix/styles/ripple';
import '@primeuix/styled';
import 'node:url';
import 'xss';

async function processAndSaveImage(fileData, fileName, filePath) {
  try {
    await sharp(fileData).png().toFile(filePath);
    return true;
  } catch (error) {
    console.error("Erro ao processar a imagem:", error);
    return false;
  }
}
const upload_post = defineEventHandler(async (event) => {
  try {
    const { username } = getRouterParams(event);
    const form = await readMultipartFormData(event);
    const baseUrl = getRequestURL(event).origin;
    const authToken = getCookie(event, "auth_token");
    const decoded = jwt.verify(authToken, "chave_secreta");
    if (!form || form.length === 0) {
      setResponseStatus(event, 400);
      return { success: false, message: "Nenhum arquivo enviado." };
    }
    const file = form.find((part) => part.name === "foto" && part.type.startsWith("image/"));
    if (!file) {
      setResponseStatus(event, 400);
      return { success: false, message: "Nenhuma imagem v\xE1lida encontrada." };
    }
    const fileExtension = file.type.split("/")[1];
    const fileName = `avatar.png`;
    const filePath = path.join("server/uploads", decoded.domain, decoded.username, fileName);
    const uploadDir = path.join(process.cwd(), "server/uploads", decoded.domain, decoded.username);
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    const imageProcessed = await processAndSaveImage(file.data, fileName, filePath);
    const imageUrl = `/${filePath}`;
    if (imageProcessed) {
      return { success: true, imageUrl, message: "Foto de perfil enviada com sucesso!" };
    } else {
      return { success: false, message: "Erro de processamento" };
    }
  } catch (error) {
    console.error("Erro ao processar upload:", error);
    setResponseStatus(event, 500);
    return { success: false, message: "Erro ao processar upload.", error: error.message };
  }
});

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map
