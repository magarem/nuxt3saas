import{bj as l,bf as o,bk as a}from"./DafJVFNx.js";function b(){a({variableName:o("scrollbar.width").name})}function c(){l({variableName:o("scrollbar.width").name})}export{b,c as u};
