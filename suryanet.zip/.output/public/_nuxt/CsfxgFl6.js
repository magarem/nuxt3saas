import"./Dr7uRJpO.js";const p=""+new URL("logo2.BjIompLv.png",import.meta.url).href;export{p as _};
