import{_ as e}from"./DlAUqK2U.js";import{c as t,o}from"./DSPLkAYv.js";const c={};function r(n,s){return o(),t("h1",null,"Testando...")}const f=e(c,[["render",r]]);export{f as default};
