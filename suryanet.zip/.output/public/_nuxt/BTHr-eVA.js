import t from"./B6jqt-95.js";import"./Be1fzYNM.js";import"./Cqkt6oKF.js";import"./Dr7uRJpO.js";import"./zI6uNArr.js";var m={name:"InputSwitch",extends:t,mounted:function(){}};export{m as default};
