import t from"./BXRFR-g3.js";import"./Be1fzYNM.js";import"./BCrlrTFu.js";import"./DafJVFNx.js";import"./sekm10bz.js";var m={name:"InputSwitch",extends:t,mounted:function(){}};export{m as default};
