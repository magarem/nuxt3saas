import t from"./DcbLZ8kr.js";import"./Be1fzYNM.js";import"./3QEDClR8.js";import"./DSPLkAYv.js";import"./Ceaa02WZ.js";var m={name:"InputSwitch",extends:t,mounted:function(){}};export{m as default};
