var t={};function a(u="pui_id_"){return Object.hasOwn(t,u)||(t[u]=0),t[u]++,`${u}${t[u]}`}export{a as u};
