import { d as defineEventHandler, g as getRouterParams, r as readBody, a as getDatabase, s as setResponseStatus } from '../../../nitro/nitro.mjs';
import bcrypt from 'bcrypt';
import require$$1 from 'crypto';
import 'better-sqlite3';
import 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'lru-cache';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@primevue/core/base/style';
import '@primevue/core/basecomponent/style';
import '@primeuix/styles/autocomplete';
import '@primeuix/utils/object';
import '@primeuix/styles/cascadeselect';
import '@primeuix/styles/checkbox';
import '@primeuix/styles/checkboxgroup';
import '@primeuix/styles/colorpicker';
import '@primeuix/styles/datepicker';
import '@primeuix/styles/floatlabel';
import '@primeuix/styles/iconfield';
import '@primeuix/styles/iftalabel';
import '@primeuix/styles/inputchips';
import '@primeuix/styles/inputgroup';
import '@primeuix/styles/inputnumber';
import '@primeuix/styles/inputotp';
import '@primeuix/styles/inputtext';
import '@primeuix/styles/knob';
import '@primeuix/styles/listbox';
import '@primeuix/styles/multiselect';
import '@primeuix/styles/password';
import '@primeuix/styles/radiobutton';
import '@primeuix/styles/radiobuttongroup';
import '@primeuix/styles/rating';
import '@primeuix/styles/select';
import '@primeuix/styles/selectbutton';
import '@primeuix/styles/slider';
import '@primeuix/styles/textarea';
import '@primeuix/styles/togglebutton';
import '@primeuix/styles/toggleswitch';
import '@primeuix/styles/treeselect';
import '@primeuix/styles/button';
import '@primeuix/styles/buttongroup';
import '@primeuix/styles/speeddial';
import '@primeuix/styles/splitbutton';
import '@primeuix/styles/datatable';
import '@primeuix/styles/dataview';
import '@primeuix/styles/orderlist';
import '@primeuix/styles/organizationchart';
import '@primeuix/styles/paginator';
import '@primeuix/styles/picklist';
import '@primeuix/styles/tree';
import '@primeuix/styles/treetable';
import '@primeuix/styles/timeline';
import '@primeuix/styles/virtualscroller';
import '@primeuix/styles/accordion';
import '@primeuix/styles/card';
import '@primeuix/styles/divider';
import '@primeuix/styles/fieldset';
import '@primeuix/styles/panel';
import '@primeuix/styles/scrollpanel';
import '@primeuix/styles/splitter';
import '@primeuix/styles/stepper';
import '@primeuix/styles/tabview';
import '@primeuix/styles/tabs';
import '@primeuix/styles/toolbar';
import '@primeuix/styles/confirmdialog';
import '@primeuix/styles/confirmpopup';
import '@primeuix/styles/dialog';
import '@primeuix/styles/drawer';
import '@primeuix/styles/popover';
import '@primeuix/styles/fileupload';
import '@primeuix/styles/breadcrumb';
import '@primeuix/styles/contextmenu';
import '@primeuix/styles/dock';
import '@primeuix/styles/menu';
import '@primeuix/styles/menubar';
import '@primeuix/styles/megamenu';
import '@primeuix/styles/panelmenu';
import '@primeuix/styles/steps';
import '@primeuix/styles/tabmenu';
import '@primeuix/styles/tieredmenu';
import '@primeuix/styles/message';
import '@primeuix/styles/inlinemessage';
import '@primeuix/styles/toast';
import '@primeuix/styles/carousel';
import '@primeuix/styles/galleria';
import '@primeuix/styles/image';
import '@primeuix/styles/imagecompare';
import '@primeuix/styles/avatar';
import '@primeuix/styles/badge';
import '@primeuix/styles/blockui';
import '@primeuix/styles/chip';
import '@primeuix/styles/inplace';
import '@primeuix/styles/metergroup';
import '@primeuix/styles/overlaybadge';
import '@primeuix/styles/scrolltop';
import '@primeuix/styles/skeleton';
import '@primeuix/styles/progressbar';
import '@primeuix/styles/progressspinner';
import '@primeuix/styles/tag';
import '@primeuix/styles/terminal';
import '@primevue/forms/form/style';
import '@primevue/forms/formfield/style';
import '@primeuix/styles/tooltip';
import '@primeuix/styles/ripple';
import '@primeuix/styled';
import 'node:url';
import 'xss';

const register_post = defineEventHandler(async (event) => {
  const { domain } = getRouterParams(event);
  const { username, email, password } = await readBody(event);
  const db = getDatabase(domain);
  try {
    if (!username || !email || !password) {
      setResponseStatus(event, 400);
      return { success: false, message: "Por favor, preencha todos os campos." };
    }
    const existingUser = db.prepare("SELECT id FROM users WHERE nome = ? OR email = ?").get(username, email);
    if (existingUser) {
      setResponseStatus(event, 400);
      return { success: false, message: "Username ou email j\xE1 existe." };
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const statement = db.prepare(`
      INSERT INTO users (nome, email, password, status)
      VALUES (?, ?, ?, ?)
    `);
    const result = statement.run(username, email, password, "pending");
    if (result.changes > 0) {
      const verificationToken = require$$1.randomBytes(20).toString("hex");
      const verificationLink = `https://suryanet.site/${domain}/verify-email/${verificationToken}`;
      const userId = db.prepare("SELECT last_insert_rowid() AS id").get().id;
      db.prepare(`
        UPDATE users
        SET verificationToken = ?, verificationTokenExpiry = ?
        WHERE id = ?
      `).run(verificationToken, Date.now() + 76e5, userId);
      const emailParams = {
        from: {
          email: "magaweb@magaweb.com.br",
          // Seu email remetente
          name: "Super Saas"
          // Nome do remetente
        },
        to: [
          {
            email
            // Email do destinatário
          }
        ],
        subject: "Por favor, verifique seu email",
        html: `
          <p>Obrigado por se registrar! Clique <a href="${verificationLink}">aqui</a> para verificar seu email.</p>
        `
      };
      try {
        const emailResult = await $fetch("/api/send-email", {
          method: "POST",
          body: {
            to: emailParams.to[0].email,
            name: username,
            subject: emailParams.subject,
            html: emailParams.html
          }
        });
        if (emailResult.success) {
          return { success: true, message: "Email enviado com sucesso" };
        }
      } catch (error) {
        return { success: false, message: "Falha ao enviar email", error: error.message };
      }
    } else {
      setResponseStatus(event, 500);
      return { success: false, message: "Falha ao registrar o usu\xE1rio." };
    }
  } catch (error) {
    console.error("Erro ao registrar usu\xE1rio:", error);
    setResponseStatus(event, 500);
    return { success: false, message: "Erro interno do servidor.", error: error.message };
  } finally {
    if (db) {
      db.close();
    }
  }
});

export { register_post as default };
//# sourceMappingURL=register.post.mjs.map
