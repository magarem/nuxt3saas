import { d as defineEventHandler, r as readBody, a as getDatabase, f as createError, h as setCookie } from '../../../nitro/nitro.mjs';
import jwt from 'jsonwebtoken';
import 'better-sqlite3';
import 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'lru-cache';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import '@primevue/core/base/style';
import '@primevue/core/basecomponent/style';
import '@primeuix/styles/autocomplete';
import '@primeuix/utils/object';
import '@primeuix/styles/cascadeselect';
import '@primeuix/styles/checkbox';
import '@primeuix/styles/checkboxgroup';
import '@primeuix/styles/colorpicker';
import '@primeuix/styles/datepicker';
import '@primeuix/styles/floatlabel';
import '@primeuix/styles/iconfield';
import '@primeuix/styles/iftalabel';
import '@primeuix/styles/inputchips';
import '@primeuix/styles/inputgroup';
import '@primeuix/styles/inputnumber';
import '@primeuix/styles/inputotp';
import '@primeuix/styles/inputtext';
import '@primeuix/styles/knob';
import '@primeuix/styles/listbox';
import '@primeuix/styles/multiselect';
import '@primeuix/styles/password';
import '@primeuix/styles/radiobutton';
import '@primeuix/styles/radiobuttongroup';
import '@primeuix/styles/rating';
import '@primeuix/styles/select';
import '@primeuix/styles/selectbutton';
import '@primeuix/styles/slider';
import '@primeuix/styles/textarea';
import '@primeuix/styles/togglebutton';
import '@primeuix/styles/toggleswitch';
import '@primeuix/styles/treeselect';
import '@primeuix/styles/button';
import '@primeuix/styles/buttongroup';
import '@primeuix/styles/speeddial';
import '@primeuix/styles/splitbutton';
import '@primeuix/styles/datatable';
import '@primeuix/styles/dataview';
import '@primeuix/styles/orderlist';
import '@primeuix/styles/organizationchart';
import '@primeuix/styles/paginator';
import '@primeuix/styles/picklist';
import '@primeuix/styles/tree';
import '@primeuix/styles/treetable';
import '@primeuix/styles/timeline';
import '@primeuix/styles/virtualscroller';
import '@primeuix/styles/accordion';
import '@primeuix/styles/card';
import '@primeuix/styles/divider';
import '@primeuix/styles/fieldset';
import '@primeuix/styles/panel';
import '@primeuix/styles/scrollpanel';
import '@primeuix/styles/splitter';
import '@primeuix/styles/stepper';
import '@primeuix/styles/tabview';
import '@primeuix/styles/tabs';
import '@primeuix/styles/toolbar';
import '@primeuix/styles/confirmdialog';
import '@primeuix/styles/confirmpopup';
import '@primeuix/styles/dialog';
import '@primeuix/styles/drawer';
import '@primeuix/styles/popover';
import '@primeuix/styles/fileupload';
import '@primeuix/styles/breadcrumb';
import '@primeuix/styles/contextmenu';
import '@primeuix/styles/dock';
import '@primeuix/styles/menu';
import '@primeuix/styles/menubar';
import '@primeuix/styles/megamenu';
import '@primeuix/styles/panelmenu';
import '@primeuix/styles/steps';
import '@primeuix/styles/tabmenu';
import '@primeuix/styles/tieredmenu';
import '@primeuix/styles/message';
import '@primeuix/styles/inlinemessage';
import '@primeuix/styles/toast';
import '@primeuix/styles/carousel';
import '@primeuix/styles/galleria';
import '@primeuix/styles/image';
import '@primeuix/styles/imagecompare';
import '@primeuix/styles/avatar';
import '@primeuix/styles/badge';
import '@primeuix/styles/blockui';
import '@primeuix/styles/chip';
import '@primeuix/styles/inplace';
import '@primeuix/styles/metergroup';
import '@primeuix/styles/overlaybadge';
import '@primeuix/styles/scrolltop';
import '@primeuix/styles/skeleton';
import '@primeuix/styles/progressbar';
import '@primeuix/styles/progressspinner';
import '@primeuix/styles/tag';
import '@primeuix/styles/terminal';
import '@primevue/forms/form/style';
import '@primevue/forms/formfield/style';
import '@primeuix/styles/tooltip';
import '@primeuix/styles/ripple';
import '@primeuix/styled';
import 'node:url';
import 'xss';

const SECRET_KEY = "chave_secreta";
function verificarLoginPorNome(db, nomeDigitado, senhaDigitada) {
  try {
    const stmt = db.prepare(`
      SELECT
          u.id,
          u.nome as nome,
          u.email,
          u.telefone,
          u.password as password,
          u.status,
          GROUP_CONCAT(r.name, ', ') AS roles_names,
          GROUP_CONCAT(ur.role_id) AS roles_ids
        FROM users u
        LEFT JOIN user_roles ur ON u.id = ur.user_id
        LEFT JOIN roles r ON ur.role_id = r.id
        WHERE (u.nome = ? or u.email = ?)AND u.status != 'pending'
        GROUP BY u.id, u.nome, u.email, u.telefone, u.password, u.status
        
    `);
    const usuarioEncontrado = stmt.get(nomeDigitado, nomeDigitado);
    console.log("usuarioEncontrado:", usuarioEncontrado);
    if (usuarioEncontrado && usuarioEncontrado.password === senhaDigitada) {
      return { sucesso: true, usuario: usuarioEncontrado };
    }
    return { sucesso: false, mensagem: "Nome de usu\xE1rio ou senha inv\xE1lidos" };
  } catch (error) {
    console.error("Erro ao verificar login:", error);
    return { sucesso: false, mensagem: "Erro interno ao verificar login" };
  }
}
const login = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const domain = event.context.params.domain;
  const db = getDatabase(domain);
  const findUser = verificarLoginPorNome(db, body.username, body.password);
  if (!findUser.sucesso) {
    throw createError({ statusCode: 401, statusMessage: "Credenciais inv\xE1lidas" });
  }
  const token = jwt.sign({
    timeStamp: (/* @__PURE__ */ new Date()).getTime(),
    id: findUser.usuario.id,
    email: findUser.usuario.email,
    domain,
    username: findUser.usuario.nome,
    roles: findUser.usuario.roles_ids
  }, SECRET_KEY, { expiresIn: "1h" });
  setCookie(event, "auth_token", token, {
    httpOnly: true,
    secure: true,
    sameSite: "strict",
    path: "/",
    maxAge: 3600
  });
  ({ ...findUser.usuario });
  return { success: true, message: "Login realizado com sucesso", token };
});

export { login as default };
//# sourceMappingURL=login.mjs.map
