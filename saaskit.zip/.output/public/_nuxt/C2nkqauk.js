import t from"./mxTyUeyy.js";import"./Be1fzYNM.js";import"./p9IZLZlI.js";import"./CJKqvzGe.js";import"./CCDhufQq.js";var m={name:"InputSwitch",extends:t,mounted:function(){}};export{m as default};
