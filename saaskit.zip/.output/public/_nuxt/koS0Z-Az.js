import{b8 as l,b9 as o,ba as a}from"./C7Nq-c6U.js";function b(){a({variableName:o("scrollbar.width").name})}function c(){l({variableName:o("scrollbar.width").name})}export{b,c as u};
