import t from"./DXKPp5kX.js";import"./Be1fzYNM.js";import"./CYykEGC_.js";import"./C7Nq-c6U.js";import"./Dey5ko6C.js";var m={name:"InputSwitch",extends:t,mounted:function(){}};export{m as default};
