import"./C7Nq-c6U.js";const t=""+new URL("logo-saaskit.k6vHkBd5.png",import.meta.url).href;export{t as _};
