import{_ as e}from"./DlAUqK2U.js";import{v as t,x as o}from"./CJKqvzGe.js";const r={};function c(n,s){return o(),t("h1",null,"Testando...")}const f=e(r,[["render",c]]);export{f as default};
